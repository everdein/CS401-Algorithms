/**
 * Matthew Clark
 * CS401 Algorithms
 * Assignment 4 - A Social-Network Based Recommendation System for last.fm.
**/

// Algs4 imports.
import edu.princeton.cs.algs4.Digraph;
import edu.princeton.cs.algs4.EdgeWeightedDigraph;
import edu.princeton.cs.algs4.In;
import edu.princeton.cs.algs4.Stack;
import edu.princeton.cs.algs4.DirectedEdge;
import edu.princeton.cs.algs4.MinPQ;

// Java imports.
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;

public class SocialNetworkSystem
{
    public static Digraph directedGraph1 = new Digraph(2101);
    public static EdgeWeightedDigraph edgeWeightedDigraph = new EdgeWeightedDigraph(18746);
    public static Map<Integer, String> hashMap = new HashMap<>();

    // Main method.
    public static void main(String[] args)
    {
        // Sets file name.
        String fileName1 = "user_friends.dat";
        createUserFriendGraph(fileName1);

        // Sets file name.
        String fileName2 = "user_artists.dat";
        createUserArtistsGraph(fileName2);

        // Sets file name.
        String fileName3 = "artists.dat";
        getArtists(fileName3);

        // Declares user ID.
        int user = 3;
        int user1 = 4;
        int user2 = 5;

        // Calls queries.
        listFriends(user);
        commonFriends(user1, user2);
        listArtists(user1, user2);
        listTop10();
        recommend10(user);
    }

    // Creates the user friend graph.
    public static void createUserFriendGraph(String fileName1)
    {
        List<Integer> list = getVerticesAndUserFriendsFileSize(fileName1);
        int fileSize = list.get(1);

        In in = new In(fileName1);
        in.readLine();
        for(int i = 0; i < fileSize; i++)
        {
            int v = in.readInt();
            int w = in.readInt();
            directedGraph1.addEdge(v, w);
        }
    }

    // Gets the vertices and user friends file size.
    public static List getVerticesAndUserFriendsFileSize(String fileName1)
    {
        In in = new In(fileName1);
        in.readLine();
        HashSet hashSet = new HashSet();

        int fileSize = 0;
        while(!in.isEmpty())
        {
            int userID = in.readInt();
            int friendID = in.readInt();
            hashSet.add(userID);
            fileSize++;
        }
        List<Integer> list = new ArrayList();
        list.add(hashSet.size());
        list.add(fileSize);
        return list;
    }

    // Creates the user artists graph.
    public static void createUserArtistsGraph(String fileName2)
    {
        List<Integer> list = getVerticesAndUserArtistsFileSize(fileName2);
        int fileSize = list.get(1);

        In in = new In(fileName2);
        in.readLine();
        for(int i = 0; i < fileSize; i++)
        {
            int v = in.readInt();
            int w = in.readInt();
            int weight = in.readInt();
            DirectedEdge directedEdge = new DirectedEdge(v, w, weight);
            edgeWeightedDigraph.addEdge(directedEdge);
        }
    }

    // Creates the Reads the file to get vertices and file size.
    public static List getVerticesAndUserArtistsFileSize(String fileName2)
    {
        In in = new In(fileName2);
        in.readLine();
        HashSet hashSet = new HashSet();

        int fileSize = 0;
        while(!in.isEmpty())
        {
            int userID = in.readInt();
            int friendID = in.readInt();
            int weight = in.readInt();
            hashSet.add(userID);
            fileSize++;
        }
        List<Integer> list = new ArrayList();
        list.add(hashSet.size());
        list.add(fileSize);
        return list;
    }

    // Reads the artist.dat file and parses each line to get the artist id and name.
    // Then stores these variables into a hash map.
    public static void getArtists(String fileName3)
    {
        In in = new In(fileName3);
        in.readLine();
        while(!in.isEmpty())
        {
            String line = in.readLine();
            String[] parts = line.split("\\s+");
            String artist = "";
            for(int i = 1; i < parts.length - 2; i++)
            {
                artist += parts[i] + " ";
            }
            hashMap.put(Integer.parseInt(parts[0]), artist);
        }
    }

    // Prints the list of friends of the given user.
    public static void listFriends(int user)
    {
        System.out.println("List Friends Method:\n--------------------");
        System.out.print("User "+ user + "is friends with");
        for (int friend : directedGraph1.adj(user))
        {
            System.out.print(" " + friend);
        }
        System.out.println(".\n");
    }

    // Prints the user1's friends in common with user2.
    public static void commonFriends(int user1, int user2)
    {
        System.out.println("Common Friends Method:\n----------------------");
        for (int friend1 : directedGraph1.adj(user1))
        {
            for (int friend2 : directedGraph1.adj(user2))
            {
                if(friend1 == friend2)
                {
                    System.out.println("User: "+ user1 + " and User: " + user2 + " have user " + friend1 + " in common.");
                }
            }
        }
        System.out.println();
    }

    // Prints the list of artists listened by both users.
    public static void listArtists(int user1, int user2)
    {
        System.out.println("List Artists Method:\n--------------------");
        for (DirectedEdge directedEdge1 : edgeWeightedDigraph.adj(user1))
        {
            for (DirectedEdge directedEdge2 : edgeWeightedDigraph.adj(user2))
            {
                if(directedEdge1.to() == directedEdge2.to())
                {
                    System.out.println("User: "+ user1 + " and User: " + user2 + " have user " + hashMap.get(directedEdge1.to()) + "in common.");
                }
            }
        }
        System.out.println();
    }

    // Prints the list of top 10 most popular artists by all users.
    public static void listTop10()
    {
        System.out.println("Top 10 Method:\n--------------");

        // Creates two arrays to store artist weights.
        Double[] unsortedArray = new Double[18746];
        Double[] sortedArray = new Double[18746];

        // Sets all indices to 0.0.
        for(int i = 0; i < unsortedArray.length; i++)
        {
            unsortedArray[i] = 0.0;
            sortedArray[i] = 0.0;
        }

        // Adds up how many plays artists have.
        for(int i = 2; i < 2101; i++)
        {
            for (DirectedEdge directedEdge : edgeWeightedDigraph.adj(i))
            {
                unsortedArray[directedEdge.to()] = unsortedArray[directedEdge.to()] + directedEdge.weight();
                sortedArray[directedEdge.to()] = sortedArray[directedEdge.to()] + directedEdge.weight();
            }
        }

        // Sorts array.
        Arrays.sort(sortedArray);

        // Prints top 10 most listened to artists.
        for(int i = sortedArray.length - 1; i >= sortedArray.length - 10; i--)
        {
            for(int j = 0; j <= unsortedArray.length - 1; j++)
            {
                if(sortedArray[i].equals(unsortedArray[j]))
                {
                    System.out.println("Artist ID: " + j + " has " + sortedArray[i] + " plays.");
                }
            }
        }
        System.out.println();
    }

    // Recommends 10 most listened to artists by the user and friends.
    public static void recommend10(int user)
    {
        System.out.println("Recommend 10 Method:\n--------------------");

        // Creates hash map to store artist id and object.
        HashMap<Integer, Artist> artistHashMap = new HashMap<>();

        // Sets artist attributes for user.
        for(DirectedEdge directedEdge : edgeWeightedDigraph.adj(user))
        {
            // Prints artists id, name and weight.
//            System.out.println(hashMap.get(directedEdge.to()));
//            System.out.println(directedEdge.to());
//            System.out.println(directedEdge.weight() + "\n");
            fillingMapWithArtists(artistHashMap, directedEdge);
        }

        // Sets artist attribute for users friends.
        for(int friend : directedGraph1.adj(user))
        {
            for (DirectedEdge directedEdge : edgeWeightedDigraph.adj(friend))
            {
                fillingMapWithArtists(artistHashMap, directedEdge);
            }
        }

        // Creates minimum priority queue to store artists.
        MinPQ<Artist> pq = new MinPQ<>();

        for(int id : artistHashMap.keySet())
        {
            pq.insert(artistHashMap.get(id));
        }

        // Delete minimum artist weight until the priority queue is of size 10.
        int pqSize = pq.size();
        for(int i = 0; i < pqSize - 10; i++)
        {
            pq.delMin();
        }

        // Flips the priority queue using a stack to show descending artist order by weight.
        Stack<Artist> flipPQ = new Stack<>();
        for (Artist artist : pq)
        {
            flipPQ.push(artist);
        }

        // Prints most listened to artist.
        for(Artist artist : flipPQ)
        {
            System.out.println("Artist ID: " + artist.getID());
            System.out.println("Artist Name: " + artist.getName());
            System.out.println("Number of Plays: " + artist.getWeight());
            System.out.println();
        }

    }

    // Fills map with artists the user and friends listen to, and updates artist weight to maximum weight.
    private static void fillingMapWithArtists(HashMap<Integer, Artist> artistHashMap, DirectedEdge directedEdge)
    {
        // Creates artist object.
        Artist artist = new Artist();

        // Sets artist id, name and weight.
        artist.setID(directedEdge.to());
        artist.setName(hashMap.get(directedEdge.to()));
        artist.setWeight(directedEdge.weight());

        // Checks if current artist weight is greater than artist wait already stored.
        if(artistHashMap.containsKey(directedEdge.to()) &&
           artistHashMap.get(directedEdge.to()).getWeight() < artist.getWeight())
        {
            artistHashMap.put(directedEdge.to(), artist);
        }
        // Puts the artist into the hash map if not already contained.
        else if(!artistHashMap.containsKey(directedEdge.to()))
        {
            artistHashMap.put(directedEdge.to(), artist);
        }
    }
}